import os
import subprocess
import sys
import shutil

# --- НАСТРОЙКИ ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
JDK_DIR = os.path.join(BASE_DIR, "jdk")
GRADLE_DIR = os.path.join(BASE_DIR, "gradle-8.5")
SDK_DIR = os.path.join(BASE_DIR, "android-sdk")
PROJECT_DIR = os.path.join(BASE_DIR, "flash-android")

print("=== 1. ПОДГОТОВКА ОКРУЖЕНИЯ ===")
os.environ["JAVA_HOME"] = JDK_DIR
os.environ["ANDROID_HOME"] = SDK_DIR
os.environ["PATH"] = os.path.join(JDK_DIR, "bin") + os.pathsep + os.environ["PATH"]

# --- 2. ЖЕСТКАЯ ФИКСАЦИЯ РЕСУРСОВ И ИКОНКИ ---
print("=== 2. СОЗДАНИЕ ИКОНОК И РЕСУРСОВ ===")
res_dir = os.path.join(PROJECT_DIR, "app", "src", "main", "res")
icon_src = os.path.join(BASE_DIR, "icon.png")

# Создаем все папки mipmap, которые требует Android
mipmap_dirs = ["mipmap-mdpi", "mipmap-hdpi", "mipmap-xhdpi", "mipmap-xxhdpi", "mipmap-xxxhdpi"]
for m_dir in mipmap_dirs:
    target_dir = os.path.join(res_dir, m_dir)
    os.makedirs(target_dir, exist_ok=True)
    # Копируем иконку (если она есть)
    if os.path.exists(icon_src):
        shutil.copy(icon_src, os.path.join(target_dir, "ic_launcher.png"))
        print(f"[+] Иконка скопирована в {m_dir}")
    else:
        # Если иконки нет, создаем пустой файл-заглушку (чтобы сборка не падала)
        # В реальности Android требует валидный PNG, поэтому если его нет, мы просто создадим пустую папку
        print(f"[!] Внимание: icon.png не найден, папка {m_dir} пустая.")

# --- 3. ФИКСИМ GRADLE.PROPERTIES ---
print("=== 3. НАСТРОЙКА GRADLE.PROPERTIES ===")
gradle_props_path = os.path.join(PROJECT_DIR, "gradle.properties")
with open(gradle_props_path, "w") as f:
    f.write("android.useAndroidX=true\n")
    f.write("android.enableJetifier=true\n")
    f.write("org.gradle.jvmargs=-Xmx2048m\n")
print("[+] gradle.properties настроен.")

# --- 4. ЗАПУСК СБОРКИ ---
print("\n=== 4. ЗАПУСК СБОРКИ (ЖДИ) ===")
gradle_bat = os.path.join(GRADLE_DIR, "bin", "gradle.bat")

try:
    os.chdir(PROJECT_DIR)
    # Собираем debug версию
    subprocess.run([gradle_bat, "assembleDebug"], check=True)
    
    apk_path = os.path.join(PROJECT_DIR, "app", "build", "outputs", "apk", "debug", "app-debug.apk")
    
    if os.path.exists(apk_path):
        print("\n" + "="*50)
        print("🎉 УСПЕХ! APK СОБРАН!")
        print("="*50)
        print(f"Твой файл лежит тут:\n{apk_path}")
        print("\nКидай его на телефон и устанавливай!")
    else:
        print("\n⚠️ Сборка прошла, но APK не найден по пути. Проверь вручную папку build/outputs.")

except subprocess.CalledProcessError as e:
    print("\n❌ ОШИБКА СБОРКИ!")
    print("Скинь последние строки консоли мне сюда.")

input("\nНажми Enter, чтобы выйти...")